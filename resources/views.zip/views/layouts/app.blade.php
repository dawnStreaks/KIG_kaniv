<!DOCTYPE html>
<html>
<head>
    <title>@yield('title', 'Multi-Level Management System')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            max-height: 100vh;
            background-color: #343a40;
            z-index: 1000;
            overflow-y: scroll;
        }
        .sidebar .nav-link {
            color: #fff;
            padding: 0.75rem 1rem;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
            color: #fff;
        }
        .sidebar .nav-link.active {
            background-color: #007bff;
        }
        .main-content {
            margin-left: 0;
            min-height: 100vh;
        }
        @media (min-width: 768px) {
            .main-content {
                margin-left: 250px;
            }
        }
        body {
            overflow-x: hidden;
        }
        .pagination {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .pagination .page-item {
            display: inline-block;
        }
        .pagination .page-item .page-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 38px;
            width: 38px;
            font-size: 14px;
            line-height: 1;
        }
        .pagination .page-item .page-link span {
            font-size: 12px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar position-fixed d-none d-md-block" id="sidebar" style="width: 250px;">
        <div class="p-3">
            <h5 class="text-white">Kaniv System</h5>
            @auth
                <small class="text-muted">{{ auth()->user()->name }}</small>
            @endauth
        </div>
        <nav class="nav flex-column">
            @auth
                @if(auth()->user()->user_type !== 'admin' && auth()->user()->user_type !== 'center')
                    <a class="nav-link" href="{{ route('dashboard') }}">Dashboard</a>
                @endif
            @else
                <a class="nav-link" href="{{ route('dashboard') }}">Dashboard</a>
            @endauth
            
            @auth
                @if(auth()->user()->user_type == 'area')
                    <div class="px-3 py-2">
                        <small class="text-muted">AREA</small>
                    </div>
                    <a class="nav-link" href="{{ route('applications.index') }}">Applications</a>
                    <a class="nav-link" href="{{ route('collections.index') }}">Collections</a>
                    <a class="nav-link" href="{{ route('collections.report') }}">Collection Report</a>
                @elseif(auth()->user()->user_type == 'mekhala')
                    <div class="px-3 py-2">
                        <small class="text-muted">MEKHALA - {{ strtoupper(auth()->user()->role ?? 'N/A') }}</small>
                    </div>
                    <a class="nav-link" href="{{ route('applications.index') }}">Applications</a>
                    @if(auth()->user()->canApproveApplications())
                        <a class="nav-link" href="{{ route('applications.review') }}">Review Applications</a>
                    @endif
                    <a class="nav-link" href="{{ route('collections.receive') }}">Receive Collections</a>
                    @if(auth()->user()->canAddExpenses())
                        <a class="nav-link" href="{{ route('expenses.index') }}">Expenses</a>
                    @endif
                    <a class="nav-link" href="{{ route('investments.index') }}">Investments</a>
                    
                    <div class="px-3 py-2">
                        <small class="text-muted">REPORTS</small>
                    </div>
                    <a class="nav-link" href="{{ route('reports.financial') }}">Financial Statement</a>
                    <a class="nav-link" href="{{ route('reports.area-summary') }}">Area Summary</a>
                    <a class="nav-link" href="{{ route('reports.collection') }}">Collection Report</a>
                    <a class="nav-link" href="{{ route('collections.report') }}">Collection Chart Report</a>
                    <a class="nav-link" href="{{ route('collections.unit-type-comparison') }}">Unit Type Comparison</a>
                @else
                    @if(auth()->user()->user_type == 'admin' || auth()->user()->user_type == 'center')
                        <div class="px-3 py-2">
                            <small class="text-muted">{{ strtoupper(auth()->user()->user_type) }}</small>
                        </div>
                        <a class="nav-link" href="{{ route('admin.dashboard') }}">Admin Dashboard</a>
                        <a class="nav-link" href="{{ route('admin.users.index') }}">Users</a>
                        <a class="nav-link" href="{{ route('admin.areas.index') }}">Areas</a>
                        <a class="nav-link" href="{{ route('admin.mekhalas.index') }}">Mekhalas</a>
                        <a class="nav-link" href="{{ route('admin.units.index') }}">Units</a>
                        
                        <div class="px-3 py-2">
                            <small class="text-muted">SETTINGS</small>
                        </div>
                        <a class="nav-link" href="{{ route('admin.terms.index') }}">Collection Terms</a>
                        <a class="nav-link" href="{{ route('admin.types.index') }}">Collection Types</a>
                        <a class="nav-link" href="{{ route('admin.application-types.index') }}">Application Terms</a>
                        <a class="nav-link" href="{{ route('admin.expense-types.index') }}">Expense Types</a>
                        <a class="nav-link" href="{{ route('admin.opening-balance') }}">Opening Balance</a>
                        
                        <div class="px-3 py-2">
                            <small class="text-muted">MAIN</small>
                        </div>
                        <a class="nav-link" href="{{ route('applications.index') }}">Applications</a>
                        <a class="nav-link" href="{{ route('collections.index') }}">Collections</a>
                        <a class="nav-link" href="{{ route('collections.center-receive') }}">Center Receive Collections</a>
                        @if(auth()->user()->user_type !== 'center')
                            <a class="nav-link" href="{{ route('applications.review') }}">Review Applications</a>
                        @endif
                        <a class="nav-link" href="{{ route('expenses.index') }}">Expenses</a>
                        @if(auth()->user()->canAddInvestments())
                            <a class="nav-link" href="{{ route('investments.index') }}">Investments</a>
                        @endif
                        
                        <div class="px-3 py-2">
                            <small class="text-muted">REPORTS</small>
                        </div>
                        <a class="nav-link" href="{{ route('reports.east-financial') }}">East Mekhala Financial</a>
                        <a class="nav-link" href="{{ route('reports.west-financial') }}">West Mekhala Financial</a>
                        <a class="nav-link" href="{{ route('reports.combined-financial') }}">Combined Financial</a>
                        <a class="nav-link" href="{{ route('reports.center-financial') }}">Center Financial</a>
                        <a class="nav-link" href="{{ route('reports.area-summary') }}">Area Summary</a>
                        <a class="nav-link" href="{{ route('reports.collection') }}">Collection Report</a>
                        <a class="nav-link" href="{{ route('collections.report') }}">Collection Chart Report</a>
                        <a class="nav-link" href="{{ route('collections.unit-type-comparison') }}">Unit Type Comparison</a>
                        <a class="nav-link" href="{{ route('reports.mekhala') }}">Mekhala Report</a>
                        @if(auth()->user()->user_type !== 'center')
                            <a class="nav-link" href="{{ route('reports.application-payment') }}">Application Payment</a>
                        @endif
                    @endif
                @endif
            @endauth
            
            <div class="px-3 py-2 mt-4">
                <small class="text-muted">ACCOUNT</small>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link text-start w-100 border-0 bg-transparent text-white">Logout</button>
            </form>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navigation for Mobile -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark d-md-none">
            <div class="container-fluid">
                <a class="navbar-brand" href="{{ route('dashboard') }}">Kaniv System</a>
                <button class="btn btn-outline-light" type="button" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </nav>

        <div class="container-fluid p-4">
            @yield('content')
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script>
        // Toggle sidebar for mobile
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('d-none');
        }
        
        // Set active navigation link
        document.addEventListener('DOMContentLoaded', function() {
            const currentPath = window.location.pathname;
            const navLinks = document.querySelectorAll('.sidebar .nav-link');
            
            navLinks.forEach(link => {
                if (link.getAttribute('href') === currentPath) {
                    link.classList.add('active');
                }
            });
            
            // Handle logout forms
            const logoutForms = document.querySelectorAll('form[action*="logout"]');
            logoutForms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    // Create a fresh form with current CSRF token
                    const newForm = document.createElement('form');
                    newForm.method = 'POST';
                    newForm.action = '{{ route("logout") }}';
                    
                    const csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = '_token';
                    csrfInput.value = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                    
                    newForm.appendChild(csrfInput);
                    document.body.appendChild(newForm);
                    newForm.submit();
                });
            });
        });
    </script>
</body>
</html>